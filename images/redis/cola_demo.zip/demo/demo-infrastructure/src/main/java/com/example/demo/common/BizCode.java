package com.example.demo.common;

public class BizCode {

    public final static String BIZ_ONE = "ali.cola.demo.bizOne"; //biz one

    public final static String BIZ_TWO = "ali.cola.demo.bizTwo"; //biz two
}
