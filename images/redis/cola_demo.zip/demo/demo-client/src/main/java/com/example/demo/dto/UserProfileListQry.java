package com.example.demo.dto;

import lombok.Data;

@Data
public class UserProfileListQry extends CommonCommand {
    private String dep;
}
