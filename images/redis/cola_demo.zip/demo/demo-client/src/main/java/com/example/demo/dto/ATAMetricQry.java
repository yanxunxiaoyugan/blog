package com.example.demo.dto;

import lombok.Data;

@Data
public class ATAMetricQry extends CommonCommand {
    public String ownerId;
}

